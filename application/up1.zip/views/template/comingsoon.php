<!DOCTYPE html>
<html>

<head>
    <title>Coming Soon</title>
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/coming soon/css/comingsoon.css">
</head>

<body>

    <!-- Pembuka Blok Awal -->
    <div class="blokA1"></div>
    <div class="blokA2"></div>
    <div class="blokA3"></div>
    <!-- Penutup Blok Awal -->

    <!-- Pembuka Coming Soon -->
    <div class="comingsoon">
        <img src="<?= base_url() ?>assets/coming soon/image/BBMK.png">
        <p class="tulisan">COMING<span>SOON</span></p>
<!--         <p class="tanggal">15.03.2021</p> -->
    </div>
    <!-- Penutup Coming Soon -->

    <!-- Pembuka Blok Akhir -->
    <div class="blokB1"></div>
    <div class="blokB2"></div>
    <div class="blokB3"></div>
    <!-- Penutup Blok Akhir -->

</body>

</html>