
/*<?php
class Ukm_model extends CI_Model{
	public $nama, $deskripsi, $berdiri, $visi, $misi, $motto;

	public function updateProfile{
		
		if(isset($_POST["update"])){
			$this->nama = $this->input_stream("nama", TRUE);
			$this->deskripsi = $this->input_stream("deskripsi", TRUE);
			$this->berdiri = $this->input_stream("tgl_berdiri", TRUE);
			$this->visi = $this->input_stream("visi", TRUE);
			$this->misi = $this->input_stream("misi", TRUE);
			$this->motto = $this->input_stream("motto", TRUE);

			
		}
	}
}
?>*/